module.exports = {
    trailingComma: "none",
    tabWidth: 4,
    semi: true
};
