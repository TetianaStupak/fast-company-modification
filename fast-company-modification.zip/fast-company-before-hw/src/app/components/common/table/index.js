import Table from "./table";
import TableBody from "./tableBody";
import TableHeader from "./tableHeader";

export default Table;

export { TableBody, TableHeader };
